
const AWS = require('aws-sdk');
const fs = require('fs');
const path=require('path');
let dynamoDoc = new AWS.DynamoDB.DocumentClient();
let credentials ;
var notificationTable = "613905-LD_MDEP_NotificationConfig-initdev";
let message ;
    
class notificationService {
    constructor(event, context,callback) {
        this.event = event;
        this.context = context;
        this.callback = callback;
    }
  startProcess(type,found,email,data,creds,filteredData) {
    //  (type,found,filteredData[i].email,credentials,filteredData))
      console.log(email + 'email here');
      console.log(JSON.stringify(creds) + 'creds here');
       console.log(type + found + email + data );
       console.log("filteredData++"+ JSON.stringify(filteredData));
     // email = ["abdul.waheed@brillio.com"];
      credentials = creds;
         dynamoDoc = new AWS.DynamoDB.DocumentClient({
                    "accessKeyId": credentials.credentials.AccessKeyId,
                    "secretAccessKey": credentials.credentials.SecretAccessKey,
                    "sessionToken": credentials.credentials.SessionToken
                });
      return new Promise((resolve,reject)=>{
          console.log(type + found + email + data + filteredData);
          console.log('entering download');
          if(type === 'download' && filteredData[0].type === "download") {
                message = "File Downloaded ";
              this.processDownload(found).then((emailTextPayload)=>{
                   console.log('entering download2');
                  this.sendEmail(emailTextPayload,email).then(()=>{
                  this.updateNotification(data,message).then(()=>{
                           resolve();
                      });
             }).catch((err)=>{
              console.log(err);
                      resolve();
         });
              });
          } else  if(type ==='arrival' && filteredData[0].type === "arrival") {
                message = "File Uploaded";
              this.processUpload(found).then((emailTextPayload)=>{
                  this.sendEmail(emailTextPayload,email).then(()=>{
                        this.updateNotification(data,message).then(()=>{
                           resolve();
                      });
                  }).catch((err)=>{
                      console.log(err);
                      resolve();
                  });
              });
          } else {
               resolve();
          }
      });
  }
  
  
 
  
  processUpload(found) {
      return new Promise((resolve, reject) => {
        let emailTextPayloadObj = fs.readFileSync(path.resolve(__dirname,'./templates/upload.txt'));
            let emailTextPayload = emailTextPayloadObj.toString();
                emailTextPayload = emailTextPayload.replace("USERNAME","folder");
                emailTextPayload = emailTextPayload.replace("PATH",found.toString());
                resolve(emailTextPayload);
      });
               
  }
  
  processDownload(found) {
      return new Promise((resolve, reject) => {
        let emailTextPayloadObj = fs.readFileSync(path.resolve(__dirname,'./templates/download.txt'));
            let emailTextPayload = emailTextPayloadObj.toString();
                emailTextPayload = emailTextPayload.replace("USERNAME","folder");
               emailTextPayload = emailTextPayload.replace("PATH",found.toString());
                resolve(emailTextPayload);
      });
  }
  
    
sendEmail(emailTextPayload,email) {
        return new Promise((resolve, reject) => {
         
            let sqsPayLoad = {
                "Type": "Email",
                "VitalizeId": "v613905",
                "From": "no-reply-sftp-portal@bms.com",
              "To": email,
                //"To":userData.mail,
                "SQSUrl": "https://sqs.us-east-1.amazonaws.com/820784505615/v428096-Centralised-Service-DeadLetter-SQS-uat"
            };
            sqsPayLoad.Subject = "SFTP Notification";
            sqsPayLoad.Message = emailTextPayload;
            let param = {
                MessageBody: JSON.stringify(sqsPayLoad),
                QueueUrl: "https://sqs.us-east-1.amazonaws.com/820784505615/v428096-Centralised-Service-SQS-uat"
            };
            let sqs = new AWS.SQS();
            sqs.sendMessage(param, (err, data) => {
                if (err) console.log("Error from sendMessage", err, err.stack);
                else {
                    console.log('mail sent successfully');
                    resolve('Mail Sent Successfully');
                }
            });
        });
    
}


updateNotification(data,message) {
        return new Promise((resolve, reject) => {
        var dt = new Date();
        dt = dt.toISOString();

const params = {
        TableName: notificationTable,
        Key: {
            "record_id" : data.record_id,
            "sftp_uniue_server_name":data.sftp_uniue_server_name
        },
        UpdateExpression: "set  #ntime = :x, #nmsg = :y",
        ExpressionAttributeNames: {
            "#ntime": "lastNotificationTime",
             "#nmsg": "lastNotificationMessage"
        },
        ExpressionAttributeValues: {
            ":x": dt,
            ":y": message
        }
    };


dynamoDoc = new AWS.DynamoDB.DocumentClient({
                   "accessKeyId": credentials.credentials.AccessKeyId,
                   "secretAccessKey": credentials.credentials.SecretAccessKey,
                   "sessionToken": credentials.credentials.SessionToken
               });


dynamoDoc.update(params, function(err, data) {
   if (err){
     console.log(err);  
   } 
   else {
       resolve();
       }
});
});
}





}
module.exports = notificationService;



    

