const AWS = require('aws-sdk');
const sts = new AWS.STS();

const AssumeRole = class{
      assumeRole(accountId){
        return new Promise((resolve, reject) => { 
        
          const params = {
                RoleArn: `arn:aws:iam::${accountId}:role/FileTransferPortalAssumeRole`,
                RoleSessionName: "FileTransferportal" 
            };
            console.log("params:: params", params);
            sts.assumeRole(params, (err, data) => {
                if (err) {
                    console.log(`Error in assume role::`, err); 
                    reject("Unable to assume role " + params.RoleArn + ". Make sure this role is valid & created before calling this" + (err && err.message ? err.message : ""));
                } else {
                    //console.log(data)
                    var tempCred = {
                        credentials: data.Credentials,
                        region: "us-east-1"
                    };
                    console.log(`Resolving with creds`);
                    resolve(tempCred);
                    //return;
                }
            });
        });

    }
    
    
};

module.exports= AssumeRole;
  