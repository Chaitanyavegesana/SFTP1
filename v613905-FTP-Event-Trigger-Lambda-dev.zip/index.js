var AWS = require("aws-sdk");
var cloudwatchlogs = new AWS.CloudWatchLogs();
var dynamodb = new AWS.DynamoDB();
var credentials;
var NotificationService = require('./NotificationService');
let AssumeRole = require('./utils/assumeRole.js');
var logGroupName;
//var type;
var tableName = "v613905-File-Transfer-Portal-Log-Table-dev";
var notificationTable = "613905-LD_MDEP_NotificationConfig-initdev";
var filterPattern; // EXIT_REASON Message="Server idle timeout"
var beforeTime = 5;
var message;
var accountId = "604243847675";
var notificationService ;
var _ = require('lodash');

// var typesObj = {
//     "OPEN":"arrival",
//     "CLOSE":"download"
// };

exports.handler = (event, context, callback) => { 
      notificationService = new NotificationService(event, context);
     console.log("Events received - ", JSON.stringify(event));
     let body  = JSON.parse(event["Records"][0]["body"]);
     message = JSON.parse(body.Message);
     logGroupName = message.AlarmDescription.split(' ')[0];
    // filterPattern = message.AlarmDescription.split(' ')[1];
   //  console.log('type here' + type);
   if(message.AlarmDescription.split(' ')[1] === "OPEN") {
       filterPattern ="OPEN";
   }
//   if(message.AlarmDescription.split(' ')[1] === "CLOSE") {
//       filterPattern ="CLOSE";
//   }  
  // message = message.AlarmDescription.split(' ')[0];
   
   console.log("filterPattern here"+ filterPattern);
    assumeRoleFunc(accountId).then((creds)=>{
    credentials = creds ; 
    console.log('creds' + JSON.stringify(creds));
    getLogsStreams().then(logStreamLists => {
      console.log(JSON.stringify(logStreamLists) + 'logstreams');
        logStreamLists.forEach(elementA => {
            getAllLogEvents(elementA["logStreamName"]).then((log_events_data) => {
                var paths = [];
                var Username, sessionId, streamName;
                var type;
                log_events_data["events"].forEach(elementB => {
                    if(elementB["message"].includes("Mode=CREATE")) {
                      let path = elementB["message"].split(" ")[2].split('/sftp/')[1];
                      console.log(path + 'path hereeee');
                        paths.push('sftp/'+path); 
                        Username = elementB["message"].split(" ")[0].split(".")[0];
                       // sessionId = elementB["message"].split(" ")[0].split(".")[1];
                        //streamName = elementB["message"].split(" ")[0];
                        type = 'arrival';
                    }
                    if(elementB["message"].includes("Mode=READ")) {
                      let path = elementB["message"].split(" ")[2].split('/sftp/')[1];
                      console.log(path + 'path hereeee');
                        paths.push('sftp/'+path); 
                        Username = elementB["message"].split(" ")[0].split(".")[0];
                      //  sessionId = elementB["message"].split(" ")[0].split(".")[1];
                    //    streamName = elementB["message"].split(" ")[0];
                        type ="download";
                    }
                });
                console.log("type" + type);
                console.log("paths" + JSON.stringify(paths));
                    getNotifications(paths,type);
                  //  putLogsDetailsToDynamoDB(Username, sessionId, streamName, paths,type);
                    
                    // console.log("events data-----", {
                    //     Username: Username,
                    //     sessionId:sessionId,
                    //     streamName:streamName,
                    //     paths:paths
                    // });
                // }
              });
        });        
    });  
});
};

var getLogsStreams = function () {
  console.log('getlogstreams');
    return new Promise(async (resolve, reject) => {
        var params = {
            logGroupName: logGroupName,
            filterPattern: filterPattern,
            startTime: getEpocDateTime(message),
    
          };
          console.log("params" +JSON.stringify(params));
          cloudwatchlogs.filterLogEvents(params, function(err, data) {
            if (err) {
              console.log('err');
                console.log(err, err.stack);
            } else {
                console.log('inside cloudwatch events');
                console.log(data["evenrs"] + 'events');
                resolve(data["events"]);
            }     
          });
    });
};

var getAllLogEvents = function(logStreamName) {
    return new Promise(async (resolve, reject) => {
      
      var params = {
        logGroupName: logGroupName,
        logStreamName: logStreamName,
        startFromHead: true
      };
      cloudwatchlogs.getLogEvents(params, function(err, data) {
        if (err) {
          console.log(err, err.stack);
        } else {
            resolve(data);       
        }
      });
    });
  };
  
  
 var assumeRoleFunc = function(accountId) {
       return new Promise(async(resolve,reject)=>{
         let assumeRole = new AssumeRole();
          assumeRole.assumeRole(accountId).then((creds) => {
          resolve(creds);
      });
      });
  };

var getEpocDateTime = function (message) {
    var getTimeStamp = message.StateChangeTime;
//  var getTimeStamp = "2020-08-12T09:15:45.863Z";
    console.log("Alarm State Change Time - ", getTimeStamp);
     var dt = new Date(getTimeStamp);
    dt.setMinutes( dt.getMinutes() - beforeTime );
    console.log("Logs start time - ", dt);
   // dt = "2020-08-12T17:49:07.943Z"
    
    var epocTimeStamp = Math.floor(new Date(dt));
 
    return epocTimeStamp;
  // return dt;
};



// var putLogsDetailsToDynamoDB = function(Username, LogId, streamName, paths,type) {
//   try {
//       return new Promise(async (resolve, reject) => {

//         let params = {
//           ExpressionAttributeNames: {
//               "#Uid": "LogId"
//           },
//           ExpressionAttributeValues: {
//               ":id": {
//                   S: LogId
//               }
//           },
//           ProjectionExpression: "DestinationLocation, Username, StreamName",
//           FilterExpression: "#Uid = :id",
//           TableName: tableName
//       };
//         dynamodb.scan(params, function(err, data) {
//           if (err) {
//             console.log(err, err.stack);
//             resolve(err);
//           }
//           else {
//             if(data.Items.length > 0) {
//               resolve(true);
//             } else{
//               var dynamoDBPutItems = {
//                 Item: {}
//               };
          
//               dynamoDBPutItems["Item"]["Task"] = {};              
//               dynamoDBPutItems["Item"]["LogId"] = {};
//               dynamoDBPutItems["Item"]["DestinationLocation"] = {};
//               dynamoDBPutItems["Item"]["Name"] = {};
//               dynamoDBPutItems["Item"]["StreamName"] = {};
//               dynamoDBPutItems["Item"]["Time"] = {};
    
//               dynamoDBPutItems["Item"]["Task"]["S"] = 'task-' + streamName;
//               dynamoDBPutItems["Item"]["LogId"]["S"] = LogId;
//               dynamoDBPutItems["Item"]["DestinationLocation"]["S"] = JSON.stringify(paths);
//               dynamoDBPutItems["Item"]["Name"]["S"] = Username;
//               dynamoDBPutItems["Item"]["StreamName"]["S"] = streamName;
//               dynamoDBPutItems["Item"]["Time"]["S"] = new Date().toISOString();
    
//               dynamoDBPutItems["TableName"] = tableName;
           
              
//               dynamodb.putItem(dynamoDBPutItems, function(err, data) {
//                 if (err) {
//                     console.log(err, err.stack);
//                     resolve(err);
//                 }
//                 else {
//                     console.log("Dynmo db inserted succesfully");
//                 //    if(paths.length){
//                         getNotifications(paths,type).then(()=>{
//                       resolve();
//                     });
//                     // }else {
//                     //     resolve();
//                     // }
//                 }
//               });
//           }
//           }
//         });
//       });
//   } catch (err) {
//       console.log("Error occured while adding record to dynamoDB", err);
//   }
// };

var getNotifications = function(paths,type){
   let dynamoDoc = new AWS.DynamoDB.DocumentClient();
     return new Promise(async (resolve, reject) => {
       console.log('inside get notifications');
            //   paths = ["sftp/Users/kumarr68/613905_prodfact/User/FromBMS/folder1/test1.txt",
            //     "sftp/Users/kumarr68/613905_prodfact/User/FromBMS/folder2/test2.txt",
            //     "sftp/Users/kumarr68/613905_prodfact/User/FromBMS/folder3/test4.txt",
            //     "sftp/Users/kumarr68/613905_prodfact/User/FromBMS/folder4/test5.txt"];
            
            
       
        getPaths(paths).then((sortedPaths)=>{
             var pathsCopy = [...sortedPaths];
       var allPaths = [];
       for(let i=0;i<sortedPaths.length;i++){
      //     if(paths[i].includes('*')){
                sortedPaths[i] = sortedPaths[i].substring(0, sortedPaths[i].lastIndexOf('/'));
          // }
         allPaths.push(sortedPaths[i]+'/');
         allPaths.push(sortedPaths[i]+'/*');
       }
       allPaths = [...new Set(allPaths)];
       
       console.log('consoling all paths here' + allPaths);
       console.log('consoling all paths here');

                dynamoDoc = new AWS.DynamoDB.DocumentClient({
                    "accessKeyId": credentials.credentials.AccessKeyId,
                    "secretAccessKey": credentials.credentials.SecretAccessKey,
                    "sessionToken": credentials.credentials.SessionToken
                });

         let params = {
                   TableName : notificationTable,
                FilterExpression:"",
                ExpressionAttributeValues:{}
           };
            
          for(let i=0;i<allPaths.length;i++) {
              if(i===0){
                  params.FilterExpression = "contains(FolderFileSpecification,:val"+i+")";
                  params.ExpressionAttributeValues[":val"+i] =  allPaths[i]; 
              }else {
                   params.FilterExpression = params.FilterExpression + " or contains(FolderFileSpecification,:val"+i+")";
                   params.ExpressionAttributeValues[":val"+i] =  allPaths[i]; 
              }
          }
           console.log(params);
                dynamoDoc.scan(params).promise().then((data) => {
                    console.log('data from Notification table' + JSON.stringify(data));
                    let filteredData = _.filter(data.Items,{"enabled":true,"type":type});
                    if(filteredData.length){
                    for(let i=0;i<filteredData.length;i++){
                     var PromiseArray = [];
                       let found = [];
                    for(let j=0;j<filteredData[i].FolderFileSpecification.length;j++){
                        let a = filteredData[i].FolderFileSpecification[j];
                         if(a.includes('*')){
                              a = a.substring(0, a.lastIndexOf('*'));
                             console.log('inside substring');
                           if (allPaths.indexOf(a) >= 0) {
                                  console.log('inside substring2');
                              for(let k = 0;k<pathsCopy.length;k++){
                                    console.log('inside k loop');
                                    console.log(pathsCopy[k] + 'paths of k');
                                   console.log('a' + a);
                                   if(pathsCopy[k].includes(a)){
                                       console.log('a' + a);
                                         console.log('inside k2 loop');
                                      found.push(pathsCopy[k]);
                                  }
                              } 
                                 found = [...new Set(found)];
                              }
                        } else {
                            console.log('coming in else');
                             if(allPaths.indexOf(a) >= 0){
                                 console.log('a here' + a);
                                    found.push(a);
                                    found = [...new Set(found)];
                                  }
                            }
                        }
                        console.log("found here" + found);
                             if(found.length){
                                  PromiseArray.push(notificationService.startProcess(type,found,filteredData[i].email,filteredData[i],credentials,filteredData));
                                  found = [];
                             }
                          Promise.all(PromiseArray).then(()=>{
                          resolve(); 
                    });
                               
                       
                    }
                    } else {
                        resolve();
                    }
                   
            //      resolve();
                });
     });
});
};



var getPaths = function(paths){
    return new Promise((resolve,reject)=>{
        let pathArray = [];
       let temp;
       for(let i=0;i<paths.length;i++){
       paths[i] = paths[i].split('/');
        for(let j=0;j<paths[i].length;j++){
         if(j===0){
         temp = paths[i][j]+'/';
         } else{
       temp = temp + paths[i][j] +'/';
         }
         if(!temp.includes('//')){
              pathArray.push(temp);
         }
         }
         }
        pathArray =[...new Set(pathArray)];
        resolve(pathArray);
    });
};